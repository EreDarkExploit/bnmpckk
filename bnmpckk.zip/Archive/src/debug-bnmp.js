import { chromium } from 'playwright';

const LOGIN_URL = 'https://portalbnmp.cnj.jus.br/#/login';
const TWO_CAPTCHA_KEY = '19c2b35edfc2415aab5c801e51f1a245';

async function main() {
  const browser = await chromium.launch({ headless: false }); // Usando headless: false para depuração visual
  const context = await browser.newContext({ viewport: { width: 1366, height: 900 } });
  const page = await context.newPage();

  console.log('Navegando para o portal...');
  await page.goto(LOGIN_URL, { waitUntil: 'networkidle' });

  // Espera o captcha aparecer
  await page.waitForSelector('iframe[src*="recaptcha"]', { timeout: 10000 }).catch(() => console.log('Iframe do captcha nao apareceu em 10s.'));

  console.log('Extraindo sitekey...');
  const sitekey = await page.evaluate(() => {
    // Procura no config global do grecaptcha se existir
    if (window.___grecaptcha_cfg && window.___grecaptcha_cfg.clients) {
        for (let cid in window.___grecaptcha_cfg.clients) {
            const client = window.___grecaptcha_cfg.clients[cid];
            for (let key in client) {
                if (client[key] && client[key].sitekey) return client[key].sitekey;
            }
        }
    }
    // Procura no DOM
    const el = document.querySelector('[data-sitekey]');
    if (el) return el.getAttribute('data-sitekey');
    // Procura no iframe
    const iframe = document.querySelector('iframe[src*="recaptcha"]');
    if (iframe) {
        const url = new URL(iframe.src);
        return url.searchParams.get('k');
    }
    return null;
  });

  if (!sitekey) {
    console.error('Nao foi possivel encontrar o sitekey.');
    await browser.close();
    return;
  }

  console.log(`Sitekey: ${sitekey}. Enviando para 2captcha (Enterprise)...`);

  const formData = new URLSearchParams();
  formData.append('key', TWO_CAPTCHA_KEY);
  formData.append('method', 'userrecaptcha');
  formData.append('googlekey', sitekey);
  formData.append('pageurl', page.url());
  formData.append('enterprise', '1'); // IMPORTANTE para reCAPTCHA Enterprise
  formData.append('json', '1');

  const resIn = await fetch('https://2captcha.com/in.php', { method: 'POST', body: formData });
  const dataIn = await resIn.json();

  if (dataIn.status !== 1) {
    console.error('Erro 2captcha IN:', dataIn.request);
    await browser.close();
    return;
  }

  const requestId = dataIn.request;
  console.log(`Captcha enviado (ID: ${requestId}). Aguardando solucao...`);

  let token = null;
  for (let i = 0; i < 60; i++) {
    await new Promise(r => setTimeout(r, 5000));
    const resOut = await fetch(`https://2captcha.com/res.php?key=${TWO_CAPTCHA_KEY}&action=get&id=${requestId}&json=1`);
    const dataOut = await resOut.json();

    if (dataOut.status === 1) {
      token = dataOut.request;
      break;
    }
    if (dataOut.request !== 'CAPCHA_NOT_READY') {
      console.error('Erro 2captcha:', dataOut.request);
      break;
    }
    process.stdout.write('.');
  }

  if (!token) {
    console.error('Falha ao obter token.');
    await browser.close();
    return;
  }

  console.log('\nToken recebido. Injetando e tentando disparar eventos...');

  await page.evaluate((t) => {
    // 1. Injeta nos textareas
    const selectors = ['#g-recaptcha-response', '[name="g-recaptcha-response"]', '.g-recaptcha-response'];
    selectors.forEach(s => {
      const el = document.querySelector(s);
      if (el) {
        el.value = t;
        el.innerHTML = t;
        // Dispara evento change
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new Event('input', { bubbles: true }));
      }
    });

    // 2. Tenta encontrar o callback no config do reCAPTCHA
    try {
      if (window.___grecaptcha_cfg && window.___grecaptcha_cfg.clients) {
        const clients = window.___grecaptcha_cfg.clients;
        for (const i in clients) {
          const client = clients[i];
          // Procura recursivamente por uma função chamada 'callback'
          const findAndCall = (obj) => {
            for (const key in obj) {
              if (key === 'callback' && typeof obj[key] === 'function') {
                console.log('Chamando callback:', key);
                obj[key](t);
              } else if (obj[key] && typeof obj[key] === 'object' && key !== 'client') {
                findAndCall(obj[key]);
              }
            }
          };
          findAndCall(client);
        }
      }
    } catch (e) { console.error('Erro ao disparar callback:', e); }

    // 3. Fallback: Se for V3 ou Enterprise sem callback explicito, pode ser que precise clicar no Login
  }, token);

  console.log('Token injetado. Tentando clicar no link de Login...');
  const loginLink = page.locator('a').filter({ hasText: /Login/i }).first();
  if (await loginLink.isVisible().catch(() => false)) {
    console.log('Botao Login visivel, clicando...');
    await loginLink.click();
  } else {
    console.log('Botao Login nao visivel. Forçando hash #/login...');
    await page.evaluate(() => window.location.hash = '#/login');
  }

  console.log('Aguardando resultado (10s)...');
  await page.waitForTimeout(10000);
  console.log('URL Final:', page.url());
  
  await page.screenshot({ path: 'debug-bnmp-result-enterprise.png' });
  console.log('Screenshot salvo em debug-bnmp-result-enterprise.png');

  await browser.close();
}

main().catch(console.error);
