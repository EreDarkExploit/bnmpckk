import { chromium } from 'playwright';
import { readFile } from 'node:fs/promises';

const LOGIN_URL = 'https://veiculos.bancopan.com.br/login';
const INVALID_MESSAGE = 'Usu\u00e1rio ou senha inv\u00e1lido';
const credentialsFile = process.env.CREDENTIALS_FILE || 'credenciais.txt';

const headless = process.env.HEADLESS === 'true';

async function carregarCredenciais() {
  if (process.env.PAN_USUARIO && process.env.PAN_SENHA) {
    return [{ usuario: process.env.PAN_USUARIO, senha: process.env.PAN_SENHA }];
  }

  const conteudo = await readFile(credentialsFile, 'utf8').catch(() => null);
  if (!conteudo) {
    console.error(`Crie ${credentialsFile} ou defina PAN_USUARIO e PAN_SENHA no ambiente.`);
    process.exit(1);
  }

  const credenciais = conteudo
    .split(/\r?\n/)
    .map((linha) => linha.trim())
    .filter((linha) => linha && !linha.startsWith('#'))
    .map((linha) => {
      const separador = linha.indexOf(':');
      if (separador === -1) {
        return {};
      }

      const usuario = linha.slice(0, separador).trim();
      const senha = linha.slice(separador + 1).trim();
      return { usuario, senha };
    })
    .filter(({ usuario, senha }) => usuario && senha);

  if (credenciais.length === 0) {
    console.error(`${credentialsFile} nao possui credenciais validas no formato usuario:senha.`);
    process.exit(1);
  }

  return credenciais;
}

const credenciais = await carregarCredenciais();
const browser = await chromium.launch({ headless });
const page = await browser.newPage({ viewport: { width: 1366, height: 900 } });

async function abrirLogin() {
  await page.goto(LOGIN_URL, { waitUntil: 'domcontentloaded' });

  const permitirCookies = page.getByRole('button', { name: 'Permitir todos os cookies' });
  if (await permitirCookies.isVisible().catch(() => false)) {
    await permitirCookies.click();
  }
}

try {
  const campoUsuario = page.getByRole('textbox', { name: /Usu.rio/i });
  const campoSenha = page.getByRole('textbox', { name: 'Senha' });
  const entrar = page.getByRole('button', { name: 'Entrar' });
  const mensagemInvalida = page.getByText(INVALID_MESSAGE, { exact: false });

  for (const [indice, credencial] of credenciais.entries()) {
    await abrirLogin();
    console.log(`Tentando credencial ${indice + 1}/${credenciais.length}: ${credencial.usuario}`);

    await campoUsuario.fill(credencial.usuario);
    await campoSenha.click();
    await campoSenha.fill(credencial.senha);

    await entrar.waitFor({ state: 'visible' });
    await entrar.click();

    const resultado = await Promise.race([
      mensagemInvalida.waitFor({ state: 'visible', timeout: 10000 }).then(() => 'invalid'),
      page.waitForLoadState('networkidle', { timeout: 10000 }).then(() => 'loaded').catch(() => 'timeout'),
    ]);

    if (resultado === 'invalid' || await mensagemInvalida.isVisible().catch(() => false)) {
      console.log(`${INVALID_MESSAGE}: ${credencial.usuario}`);
      await page.waitForTimeout(1000);
      continue;
    }

    console.log(`Mensagem de usuario/senha invalido nao encontrada para: ${credencial.usuario}`);
    break;
  }

  console.log(`URL atual: ${page.url()}`);
} finally {
  if (headless) {
    await browser.close();
  }
}
