@echo off
echo Iniciando teste de credenciais BNMP...
call npm run login:bnmp
pause
