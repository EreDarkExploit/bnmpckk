@echo off
echo [1/2] Instalando dependencias do Node...
call npm install --silent
if %errorlevel% neq 0 (
    echo Erro ao instalar dependencias. Verifique se o Node.js esta instalado.
    pause
    exit /b %errorlevel%
)

echo [2/2] Instalando navegador Chromium...
call npx playwright install chromium
if %errorlevel% neq 0 (
    echo Erro ao instalar o navegador.
    pause
    exit /b %errorlevel%
)

echo.
echo Instalacao concluida com sucesso!
echo Configure o arquivo .env e execute iniciar.bat.
pause
