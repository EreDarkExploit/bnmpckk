# Automacao go!PAN Veiculos

Automacao Playwright para abrir `https://veiculos.bancopan.com.br/login`, preencher usuario e senha, clicar em `Entrar` e verificar se aparece a mensagem `Usuario ou senha invalido`.

## Seletores encontrados

- Campo usuario: `page.getByRole('textbox', { name: 'Usuario' })`
- Campo senha: `page.getByRole('textbox', { name: 'Senha' })`
- Botao entrar: `page.getByRole('button', { name: 'Entrar' })`
- Botao cookies: `page.getByRole('button', { name: 'Permitir todos os cookies' })`

No codigo, o seletor de usuario usa regex (`/Usu.rio/i`) para evitar problema de encoding com acento.

## Como usar

Instale as dependencias:

```powershell
npm install
npx playwright install chromium
```

Execute informando uma credencial por variaveis de ambiente:

```powershell
$env:PAN_USUARIO="seu_usuario"
$env:PAN_SENHA="sua_senha"
$env:HEADLESS="false"
npm run login
```

## BNMP

Para acessar `https://portalbnmp.cnj.jus.br/#/login`, resolver o reCAPTCHA manualmente e depois preencher usuario/senha:

```powershell
$env:BNMP_USUARIO="seu_usuario"
$env:BNMP_SENHA="sua_senha"
$env:HEADLESS="false"
npm run login:bnmp
```

O navegador precisa ficar visivel (`HEADLESS=false`), porque o script aguarda voce concluir o reCAPTCHA. Depois do redirecionamento, ele procura os campos de usuario e senha, preenche e clica no botao de entrar.

Tambem e possivel usar `credenciais-bnmp.txt`:

```txt
usuario_1:senha_1
usuario_2:senha_2
```

Por padrao o script usa a primeira linha valida. Para escolher outra linha:

```powershell
$env:BNMP_CREDENTIAL_INDEX="2"
$env:HEADLESS="false"
npm run login:bnmp
```

Para usar outro arquivo:

```powershell
$env:BNMP_CREDENTIALS_FILE="meu-arquivo-bnmp.txt"
$env:HEADLESS="false"
npm run login:bnmp
```

Use `HEADLESS=true` para rodar sem abrir a janela do navegador.

Ou crie um arquivo `credenciais.txt` com uma credencial por linha:

```txt
usuario_1:senha_1
usuario_2:senha_2
```

Depois execute:

```powershell
npm run login
```

Para usar outro arquivo `.txt`:

```powershell
$env:CREDENTIALS_FILE="minhas-credenciais.txt"
npm run login
```

Ao final, o script imprime:

- `Usuario ou senha invalido`, quando a mensagem aparece na pagina.
- `Mensagem de usuario/senha invalido nao encontrada para: usuario`, quando a mensagem nao aparece dentro do tempo esperado.
